
package source;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBC implements Serializable{
    private Connection con = null;

    public DBC() throws ClassNotFoundException, SQLException {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyProject","root","root"); 
    }
    
    public ArrayList<Employee> getEmployees(){
        try {
            ArrayList<Employee> employees = new ArrayList<>();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from employee");
            
            while (rs.next()){
                Employee e = new Employee();
                
                e.seteEmail(rs.getString("e_email"));
                e.setNegativeSalary(rs.getInt("negativesalary"));
                e.seteID(rs.getString("e_id"));
                e.seteName(rs.getString("e_name"));
                e.seteWage(rs.getInt("e_wage"));
                e.setpDays(rs.getInt("pdays"));
                e.setsDays(rs.getInt("sdays"));
                
                employees.add(e);
            }
            
            return employees;
        } catch (SQLException ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public void deleteEmplpoyee(Employee e){
        try {
            
            Statement stmt = con.createStatement();
            int updated = stmt.executeUpdate("delete from employee where e_id = '"+e.geteID()+"'");
            System.out.println(updated);
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public int resetEmployees(){
        try {
            
            Statement stmt = con.createStatement();
            int updated = stmt.executeUpdate("update employee set SDAYS =14 ,PDAYS=30,NEGATIVESALARY=0");
            System.out.println(updated);
            return updated;
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    public Employee employeeLogIn(String name,String pass){
        
        try {
            PreparedStatement pstmt = con.prepareStatement("select * from employee where e_name=? and e_id=?");
            pstmt.setString(1, name);
            pstmt.setString(2, pass);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()){
                Employee e = new Employee();
                
                e.seteEmail(rs.getString("e_email"));
                e.setNegativeSalary(rs.getInt("negativesalary"));
                e.seteID(rs.getString("e_id"));
                e.seteName(rs.getString("e_name"));
                e.seteWage(rs.getInt("e_wage"));
                e.setpDays(rs.getInt("pdays"));
                e.setsDays(rs.getInt("sdays"));
                
                return e;
            }
            else {
                return null;
            }
  
        } catch (SQLException ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public int updateEmployee (Employee e) {
        
        try {
            PreparedStatement pstmt = con.prepareStatement("update employee set e_name=?,e_email=?,sdays=?,pdays=?,negativesalary=? where e_id=?");
            
            pstmt.setString(1, e.geteName());
            pstmt.setString(2, e.geteEmail());
            pstmt.setInt(3, e.getsDays());
            pstmt.setInt(4, e.getpDays());
            pstmt.setInt(5, e.getNegativeSalary());
            pstmt.setString(6, e.geteID());
            
            int updated = pstmt.executeUpdate();
            return updated;
            
        } catch (SQLException ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    public void closeCon() throws SQLException{
        con.close();
    }
    
}
