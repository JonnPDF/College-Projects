/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package source;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Youssef
 */
@WebServlet(name="CheckAccount", urlPatterns={"/CheckAccount"})
public class CheckAccount extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        try {
            
            PrintWriter out = response.getWriter();
            
            DBC db = new DBC();
            
            String name = request.getParameter("eName");
            String pass = request.getParameter("eID");
            
            Employee found = db.employeeLogIn(name, pass);
            
            db.closeCon();
            if(found != null){
                //TODO Create Registration Cycle (Done)
                request.getRequestDispatcher("RegisterVacation.jsp").forward(request, response);
            }
            else if ( name.equals("Admin") && pass.equals("admin") ) {
                //TODO Create Admin Page (Done)
                request.getRequestDispatcher("Admin.jsp").forward(request, response);
            }
            else {
                out.print("<center><h2 style='color:red;'>Employee Not Found!</h2></center>");
                request.getRequestDispatcher("Login.html").include(request, response);
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CheckAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


}
