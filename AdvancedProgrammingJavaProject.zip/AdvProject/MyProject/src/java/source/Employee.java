package source;

import java.io.Serializable;

public class Employee implements Serializable{
    private String eID, eName, eEmail;
    private int eWage, pDays,sDays,negativeSalary;
    private static final int MAXPDAYS=30,MAXSDAYS=14;

    public Employee() {
    }

    public int geteWage() {
        
        return eWage;
    }

    public void seteWage(int eWage) throws Exception {
        if(eWage<0)
        {
            throw new Exception();
        }
        this.eWage = eWage;
    }

    public String geteID() {
        return eID;
    }

    public void seteID(String eID)throws Exception  {
        String ID="eID";
        if(ID.length()>10)
        {
            throw new Exception();
        }
        this.eID = eID;
    }

    public String geteName() {
        
        return eName;
    }

    public void seteName(String eName) throws Exception {
        if(eName==null)
        {
            throw new Exception();
        }
        else{
              this.eName = eName;
        }
      
    }

    public String geteEmail() {
        return eEmail;
    }

    public void seteEmail(String eEmail) throws Exception {
        if(eEmail.matches(".*@.*.com")){
        this.eEmail = eEmail;
        }
        else {
            throw new Exception();
        }
    }

    public int getpDays() {
        return pDays;
    }

    public void setpDays(int pDays) throws Exception {
        if(pDays<0||pDays>MAXPDAYS)
        {
            throw new Exception();
        }
        else{
        this.pDays = pDays;
        }
        
    }

    public int getsDays() {
        return sDays;
    }

    public void setsDays(int sDays) throws Exception {
        if(sDays<0||sDays>MAXSDAYS)
        {
          throw new Exception(); 
        }
        else{
         this.sDays = sDays;
        }
       
    }

    public int getNegativeSalary() {
        return negativeSalary;
    }

    public void setNegativeSalary(int negativeSalary) throws Exception {
        if(negativeSalary<0)
        {
            throw new Exception();
        }
        this.negativeSalary = negativeSalary;
    }

    public static int getMAXPDAYS() {
        return MAXPDAYS;
    }

    public static int getMAXSDAYS() {
        return MAXSDAYS;
    }
    
    
}
