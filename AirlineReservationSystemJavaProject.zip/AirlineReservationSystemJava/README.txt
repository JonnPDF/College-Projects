\---------------MADE BY----------------/

1) Rawan Mourad       20104521
2) Youssef Moustafa   20104848
3) Marwan Maged       20104973
4) Hassan Mohamed     20106799
5) Ziad Amr           20106000

\---------------WITH HELP OF----------------/

-> Dr. Yasser Omar
-> Eng. Maiada Mahmoud
-> Eng. Nada Mahmoud

\---------------INSIDE THE FILE----------------/

* PowerPoint with simple Presentation of the project
* PDF with the project guidelines checked
* The Java File of the project (made with NetBeans JDK 11)
* Extra resources : Files for coding purposes & Logo for GUI purposes

\---------------NOTES----------------/

If the Program displayed File not Found Error Try To change the file paths in:
1- Schedule class --> read() method
2- Schedule class --> write() method
3- User class --> readusers() method
4- User class --> writeusers() method