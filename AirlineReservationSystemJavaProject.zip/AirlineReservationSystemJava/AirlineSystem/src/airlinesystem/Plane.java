
package airlinesystem;

public abstract class Plane implements Cloneable{
    private int Economy_seats;
    private int Business_seats;
    private final int MAXE,MAXB;
    private final String name;
    public Plane(String name,int Economy_seats,int Business_seats)
    {
    this.name=name;
    this.Economy_seats=Economy_seats;
    this.Business_seats =Business_seats;
    MAXE = Economy_seats;
      MAXB = Business_seats;   
    }
    
    public String getName() {
        return name;
    }

    public int getEconomy_seats() {
        return Economy_seats;
    }

    public int getBusiness_seats() {
        return Business_seats;
    }

    public void setEconomy_seats(int Economy_seats) {
        this.Economy_seats = Economy_seats;
    }

    public void setBusiness_seats(int Business_seats) {
        this.Business_seats = Business_seats;
    }
    
    public boolean eisavailable(){
      if(Economy_seats>0 )
          return true;
      else 
          return false;
    }
     public boolean bisavailable(){
      if( Business_seats>0)
          return true;
      else 
          return false;
    }
     
     public boolean isAvalaible() {
         return eisavailable()||bisavailable();
     }
    public void addeconomy() throws RuntimeException{
     if(Economy_seats<MAXE)
       Economy_seats++;
      else
          throw new RuntimeException();
    }
    
    public void addeconomy(int x) throws RuntimeException{
     if(Economy_seats+x<MAXE)
       Economy_seats+=x;
      else
          throw new RuntimeException();
    }
    
    public void addbusiness() throws RuntimeException{
      if(Business_seats<MAXB)
       Business_seats++;
      else
          throw new RuntimeException();
    }
    
    public void addbusiness(int x) throws RuntimeException{
      if(Business_seats+x<MAXB)
       Business_seats+=x;
      else
          throw new RuntimeException();
    }
    
    public void removeeconomy() throws RuntimeException{
      if(Economy_seats>0)
          Economy_seats--;
      else
          throw new RuntimeException();
    }
    
    public void removeeconomy(int x) throws RuntimeException{
      if(Economy_seats-x>0)
          Economy_seats-=x;
      else
          throw new RuntimeException();
    }
    
    public void removebusiness()throws RuntimeException{
      if(Business_seats>0)
          Business_seats--;
      else
          throw new RuntimeException(); 
    }
    
    public void removebusiness(int x)throws RuntimeException{
      if(Business_seats-x>0)
          Business_seats-=x;
      else
          throw new RuntimeException(); 
    }
    

    @Override
    public String toString() {
        return name;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return (Plane)super.clone();
    }
    
    
    
}
