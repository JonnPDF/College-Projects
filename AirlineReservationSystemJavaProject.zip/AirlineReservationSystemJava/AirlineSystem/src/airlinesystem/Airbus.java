package airlinesystem;


public class Airbus extends Plane{
    
    public Airbus(String name, int Economy_seats, int Business_seats) {
        super(name, Economy_seats, Business_seats);
    }
    
}
