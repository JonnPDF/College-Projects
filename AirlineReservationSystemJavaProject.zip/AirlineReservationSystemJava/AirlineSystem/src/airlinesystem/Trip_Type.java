
package airlinesystem;

public enum Trip_Type {
   OneWay, TwoWay 
}
