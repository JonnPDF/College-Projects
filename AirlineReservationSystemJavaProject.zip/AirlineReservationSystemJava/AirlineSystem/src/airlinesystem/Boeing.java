
package airlinesystem;

public class Boeing extends Plane{
    private int num_floors;

    public Boeing(int num_floors, String name, int Economy_seats, int Business_seats) {
        super(name, Economy_seats*num_floors, Business_seats*num_floors);
        this.num_floors = num_floors;
    }
    
    public int getNum_floors() {
        return num_floors;
    }

    public void setNum_floors(int num_floors) {
        
        super.setBusiness_seats(super.getBusiness_seats()/this.num_floors);
        super.setEconomy_seats(super.getEconomy_seats()/this.num_floors);
        
        this.num_floors = num_floors;
        
        super.setBusiness_seats(super.getBusiness_seats()*this.num_floors);
        super.setEconomy_seats(super.getEconomy_seats()*this.num_floors);
    }
}
