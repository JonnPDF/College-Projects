
package airlinesystem;

public interface Readable {
    void read();
    void write();
}
