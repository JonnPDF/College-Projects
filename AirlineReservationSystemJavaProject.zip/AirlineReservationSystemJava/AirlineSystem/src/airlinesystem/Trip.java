
package airlinesystem;

import java.util.GregorianCalendar;

public class Trip implements Cloneable,Comparable<Trip> {
    
    private Plane pflight;
    private static int count=0;
    private final int FLIGHTNO;
    private final String FROM,TO;
    private GregorianCalendar time;

    public Trip(Plane p,String FROM, String TO, int year, int month, int day, int hour, int minute) throws RuntimeException {
        if(year==0||month==0||day==0)
         throw new NullPointerException();
        pflight= p;
        count+=3;
        FLIGHTNO = count;
        this.FROM = FROM;
        this.TO = TO;
        this.time = new GregorianCalendar(year, month, day, hour, minute);
        if(time.getTimeInMillis()<(new GregorianCalendar()).getTimeInMillis())
            throw new IllegalArgumentException();
    }

    public Trip(Plane p, String FROM, String TO, GregorianCalendar time) {
        pflight= p;
        count++;
        FLIGHTNO = count;
        this.FROM = FROM;
        this.TO = TO;
        this.time = time;
    }

    public int getFlightno() {
        return FLIGHTNO;
    }

    public Plane getPflight() {
        return pflight;
    }

    public String getFrom() {
        return FROM;
    }

    public String getTo() {
        return TO;
    }

    public GregorianCalendar getTime() {
        return time;
    }

    public void setPflight(Plane pflight) {
        this.pflight = pflight;
    }

    public boolean isAvalaible() {
        return this.time.getTimeInMillis() > new GregorianCalendar().getTimeInMillis();
    }
    
    public void setTime(GregorianCalendar time) throws RuntimeException {
        this.time = time;
        if(time.getTimeInMillis()<(new GregorianCalendar()).getTimeInMillis())
            throw new IllegalArgumentException();
    }
    public void setTime(int year, int month, int day, int hour, int minute) throws RuntimeException {
        if(year==0||month==0||day==0)
         throw new NullPointerException();
        
        this.time = new GregorianCalendar(year, month, day, hour, minute);
        
        if(time.getTimeInMillis()<(new GregorianCalendar()).getTimeInMillis())
            throw new IllegalArgumentException();
        
    }

    @Override
    public Trip clone() throws CloneNotSupportedException {
        Trip temp = (Trip)super.clone();
        temp.pflight = (Plane)pflight.clone();
        temp.time = (GregorianCalendar)time.clone();
        return temp;
    }

    @Override
    public int compareTo(Trip other) {
        if(this.time.getTimeInMillis()>other.time.getTimeInMillis())
            return 1;
        else if (this.time.getTimeInMillis()<other.time.getTimeInMillis())
            return -1;
        else
            return 0;
    }

    @Override
    public String toString() {
        int year,month,day;
        year = time.get(GregorianCalendar.YEAR);
        month=  time.get(GregorianCalendar.MONTH);
        day =  time.get(GregorianCalendar.DAY_OF_MONTH);
        int hour = time.get(GregorianCalendar.HOUR_OF_DAY);
        int minutes = time.get(GregorianCalendar.MINUTE);
        return String.format("%04d", FLIGHTNO)+" / "+String.format("%02d", day)+"-"+String.format("%02d", month)+"-"+String.format("%02d", year)+" "+String.format("%02d", hour)+":"+String.format("%02d", minutes)+" "+FROM+" "+TO+" "+pflight;
    }
    
}
