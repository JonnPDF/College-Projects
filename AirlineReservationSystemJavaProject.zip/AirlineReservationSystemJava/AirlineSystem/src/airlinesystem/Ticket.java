
package airlinesystem;


class Ticket implements Registable{
    private Trip t;
    private int seats;
    private final Integer ID ;
    private static Integer count=0;
    
    private User u;
    private Trip_Type triptype;
    private Seat_Type seatType;
    
    public Ticket(Trip t, User u,Seat_Type seatType,Trip_Type triptype , int seats) throws RuntimeException
    {
        this.t = t;
        this.u = u;
        this.seatType=seatType;
        this.seats=seats;
        try {
        if(seatType==Seat_Type.economy)
        {
                deleteESeats(seats);
        }
        if(seatType==Seat_Type.business)
        {   
                deleteBSeats(seats);
        }
        }
        catch(Exception e) {
            throw new RuntimeException();
        }
        this.triptype=triptype; 
        count = count + 1; //Autounboxing & Autoboxing
        ID = count; //Autoboxing
    }

    public int getSeats() {
        return seats;
    }

    public int getId() {
        return ID;
    }

    public Seat_Type getSeatType() {
        return seatType;
    }

    public Trip_Type getTripType() {
        return triptype;
    }

    public Trip getT() {
        return t;
    }

    public void setT(Trip t) {
        this.t = t;
    }

    public void setTriptype(Trip_Type triptype) {
        this.triptype = triptype;
    }

    public void setSeatType(Seat_Type seatType) throws RuntimeException {
        try {
        if(this.seatType==Seat_Type.economy)
            addESeats(this.seats);
        else if (this.seatType==Seat_Type.business)
            addBSeats(this.seats);
        
        this.seatType = seatType;
        
        if(this.seatType==Seat_Type.economy)
            deleteESeats(this.seats);
        else if (this.seatType==Seat_Type.business)
            deleteBSeats(this.seats);
        }
        catch (RuntimeException e)
        {
            throw new RuntimeException();
        }
    }

    public void setSeats(int seats) throws RuntimeException {
        
       try {
        if(this.seatType==Seat_Type.economy)
            addESeats(this.seats);
        else if (this.seatType==Seat_Type.business)
            addBSeats(this.seats);
        
        this.seats = seats;
        
        if(this.seatType==Seat_Type.economy)
            deleteESeats(this.seats);
        else if (this.seatType==Seat_Type.business)
            deleteBSeats(this.seats);
        }
        catch (RuntimeException e)
        {
            throw new RuntimeException();
        }
        
    }

    @Override
    public String toString() {
        return "ID: "+ID+"\nFlight:\n"+t+"\nNO of seats: "+seats+"\tTrip type: "+triptype+"\tTrip type: "+triptype+"\tSeat type: "+seatType+"\nPassenger name: "+u.getName();
    }

    @Override
    public void addESeats(int x) throws RuntimeException {
        try {
            if(x>1)
                t.getPflight().addeconomy(x); 
            else if (x==1)
                t.getPflight().addeconomy();
            else
                throw new RuntimeException();
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    @Override
    public void deleteESeats(int x) throws RuntimeException {
        try {
            if(x>1)
                t.getPflight().removeeconomy(x);
            else if (x==1)
                t.getPflight().removeeconomy();
            else
                throw new RuntimeException();
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    @Override
    public void addBSeats(int x) throws RuntimeException {
        try {
            if(x>1)
                t.getPflight().addbusiness(x); 
            else if (x==1)
                t.getPflight().addbusiness();
            else
                throw new RuntimeException();
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    @Override
    public void deleteBSeats(int x) throws RuntimeException {
        try {
            if(x>1)
                t.getPflight().removebusiness(x);
            else if (x==1)
                t.getPflight().removebusiness();
            else
                throw new RuntimeException();
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
    
    
    
}
