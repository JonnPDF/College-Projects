
package airlinesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class Schedule implements Readable{
    
    private File filein,fileout;
    private PrintWriter output;
    private Scanner input;
    private ArrayList<Trip> flights = new ArrayList<>();

    public Schedule() throws RuntimeException {
        
        filein = new File("D:\\Flights.txt");
        fileout = new File("D:\\FlightsReport.txt");
        try {
            input = new Scanner(filein); //Checked Exception
            output = new PrintWriter(fileout);
        } catch (FileNotFoundException ex) {
            
            throw new RuntimeException();
        }
        
    }
    
    
    @Override
    public void read() {
        while(input.hasNext())
        {
            String[] sub = (input.nextLine()).split(" ");
            
            String [] dates = sub[0].split("-");
            int day = Integer.parseInt(dates[0]);
            int month = Integer.parseInt(dates[1]);
            int year = Integer.parseInt(dates[2]);
            
            String[] times = sub[1].split(":");
            int hour = Integer.parseInt(times[0]);
            int minutes = Integer.parseInt(times[1]);
          
            if(sub[4].matches("A.*"))
            {
                try {
                    flights.add(new Trip(new Airbus(sub[4],150,20),sub[2],sub[3],year,month,day,hour,minutes));
                } catch (Exception e) {
                    continue;
                }
            }
            else if(sub[4].matches("B.*"))
            {
                try {
                    flights.add(new Trip(new Boeing(2,sub[4],200,40),sub[2],sub[3],year,month,day,hour,minutes));
                } catch (Exception e) {
                    continue;
                }
            }
            
        }
        input.close();
    }
    
    @Override
    public void write() {
        Collections.sort(flights);
        for (int i = 0; i < flights.size(); i++) {
            if(flights.get(i).isAvalaible()&&flights.get(i).getPflight().isAvalaible())
            output.print(flights.get(i)+"\n");
            
        }
        output.close();
    }

    public ArrayList<Trip> getFlights() {
        return flights;
    }
    
    
}
