
package airlinesystem;

public interface Modifiable {
    void modify(Trip newTrip,Seat_Type newSeat_Type,Trip_Type newTrip_Type,int newSeats);
    void delete();
}
