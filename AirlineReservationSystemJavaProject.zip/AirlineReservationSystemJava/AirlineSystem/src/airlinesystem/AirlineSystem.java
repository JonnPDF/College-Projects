
package airlinesystem;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;



public class AirlineSystem implements ActionListener{

    
    static User temp;
    static Schedule s;
    static Seat_Type seat_Type;
    static Trip trip;
    static int seats;
    static Trip_Type trip_Type;

    public static void main(String[] args)  {
        
        
        
        //------READING FILES------
        try {
            s = new Schedule();
            s.read();
            User.readusers();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"COULDN'T FIND REQUIRED FILES!!!", "Files Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        
        
        JFrame mainFrame = new JFrame();
        JFrame loginFrame = new JFrame();
        JFrame signupFrame = new JFrame();
        JFrame registerFrame = new JFrame();
        //-------------------------------MAIN FRAME-------------------------------------
        
        
        JButton loginButton,signupButton,reportButton;
        
         //-------------TITLE------------
        JLabel label = new JLabel("Airline Reservation Login");
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Times New Roman",Font.BOLD,30));
        label.setBounds(93, 0, 500, 100);
        
        //-----------REPORT BUTTON----------
        reportButton=new JButton("Generate report");
        reportButton.addActionListener((e) -> {
            try {
                s.write();
                JOptionPane.showMessageDialog(null, "Report printed successfully!", "Success report", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception exp) {
                JOptionPane.showMessageDialog(null, "Report failed!", "Failed Report", JOptionPane.ERROR_MESSAGE);
            }
            
        });
        reportButton.setBounds(160, 370, 200, 40);
        reportButton.setFocusable(false);
        reportButton.setFont(new Font("Times New Roman",Font.BOLD,20));
        reportButton.setBorder(BorderFactory.createEtchedBorder());
        
        //-------------LOGIN BUTTON----------
        loginButton=new JButton();
        loginButton.setBounds(185,200,150,40);
        loginButton.addActionListener((e) -> {
            mainFrame.setVisible(false);
            loginFrame.setVisible(true);
            
        });
        loginButton.setText("Login");
        loginButton.setFocusable(false);
        loginButton.setFont(new Font("Times New Roman",Font.BOLD,21));
        loginButton.setBorder(BorderFactory.createEtchedBorder());
        
        
        //----------SIGNUP BUTTON------------
        signupButton=new JButton();
        signupButton.setBounds(185,290,150,40);
        signupButton.addActionListener((e) -> {
            mainFrame.setVisible(false);
            signupFrame.setVisible(true);
        });
        signupButton.setText("Signup");
        signupButton.setFocusable(false);
        signupButton.setFont(new Font("Times New Roman",Font.BOLD,20));
        signupButton.setBorder(BorderFactory.createEtchedBorder());
        
     //---------FRAME BODY------------   
  mainFrame.setTitle("Airline Reservation System"); 
  mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
  mainFrame.setResizable(false); 
  mainFrame.setSize(550,550); 
  mainFrame.setLayout(null);
  mainFrame.setVisible(true); 
  mainFrame.add(label);
  mainFrame.add(loginButton);
  mainFrame.add(signupButton);
  mainFrame.add(reportButton);
  
  ImageIcon image = new ImageIcon("C:\\Users\\Youssef\\Desktop\\applogo.png"); 
  mainFrame.setIconImage(image.getImage()); 
  mainFrame.getContentPane().setBackground(new Color(0x123456));
        
        
        //-----------------------------LOGIN FRAME------------------------------------------
        JButton loginback;
        JTextField loginemail = new JTextField();
        JTextField loginpin = new JTextField();
        JButton logsubmit = new JButton("Submit");
        JLabel loginLabel = new JLabel("Login");
        JLabel emailLabel = new JLabel();
        JLabel pinLabel = new JLabel();
        
        //----------LOGIN TITLE---------------
        loginLabel.setHorizontalTextPosition(JLabel.CENTER);
        loginLabel.setForeground(Color.WHITE);
        loginLabel.setFont(new Font("Times New Roman",Font.BOLD,30));
        loginLabel.setBounds(200, 0, 500, 100); 
        
        //----------LOGIN EMAIL TEXT-----------
        loginemail.setFont(new Font("Consolas",Font.PLAIN,15));
        loginemail.setBounds(200, 160, 250, 25);
        emailLabel.setText("E-mail");
        emailLabel.setFont(new Font("Consolas",Font.BOLD,18));
        emailLabel.setBounds(120, 165, 100, 25);
        emailLabel.setForeground(Color.WHITE);
        
        //-------LOGIN PIN TEXT-----------
        loginpin.setFont(new Font("Consolas",Font.PLAIN,15));
        loginpin.setBounds(200, 240, 250, 25);
        pinLabel.setText("Pincode");
        pinLabel.setFont(new Font("Consolas",Font.BOLD,18));
        pinLabel.setBounds(120, 245, 100, 25);
        pinLabel.setForeground(Color.WHITE);
        
        //--------LOGIN SUBMIT BUTTON---------
        logsubmit.setBounds(400, 420, 100, 40);
        logsubmit.setFocusable(false);
        logsubmit.setFont(new Font("Times New Roman",Font.BOLD,20));
        logsubmit.setBorder(BorderFactory.createEtchedBorder());
        logsubmit.addActionListener((e) -> {
            String email = loginemail.getText();
            String pincode = loginpin.getText();
            temp = User.login(email, pincode);
            if(temp==null)
                {
                    JOptionPane.showMessageDialog(null, "Password or Email doesn't exist!", "Failed Login", JOptionPane.WARNING_MESSAGE);
                }
            else {
                loginFrame.setVisible(false);
                registerFrame.setVisible(true);
            }
        });
        
        
        
        //-----------BACK BUTTON-----------
        loginback=new JButton();
        loginback.addActionListener((e) -> {
            loginFrame.setVisible(false);
            mainFrame.setVisible(true);
            
        });
        loginback.setText("Back");
        loginback.setBounds(Rectangle.OUT_LEFT, 470, 100, 40);
        loginback.setFocusable(false);
        loginback.setFont(new Font("Times New Roman",Font.BOLD,20));
        loginback.setBorder(BorderFactory.createEtchedBorder());
        
        //-----------FRAME BODY--------------
        loginFrame.setTitle("Airline Reservation System"); 
  loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
  loginFrame.setResizable(false); 
  loginFrame.setSize(550,550); 
  loginFrame.setLayout(null);
  loginFrame.add(loginLabel);
  loginFrame.add(loginemail);
  loginFrame.add(loginpin);
  loginFrame.add(emailLabel);
  loginFrame.add(pinLabel);
  loginFrame.add(logsubmit);
  loginFrame.add(loginback);
  loginFrame.setIconImage(image.getImage()); 
  loginFrame.getContentPane().setBackground(new Color(0x123456)); 
  loginFrame.setVisible(false);
        
        
        //----------------------------SIGNUP FRAME-------------------------------
        JButton signupback;
        JTextField signupemail = new JTextField();
        JTextField signupname = new JTextField();
        JTextField signuppin = new JTextField();
        JButton signsubmit = new JButton("Submit");
        JLabel signupLabel = new JLabel("Signup");
        JLabel signuserLabel = new JLabel();
        JLabel signemailLabel = new JLabel();
        JLabel signpinLabel = new JLabel();
        
        //--------SIGNUP TITLE-----------
        signupLabel.setHorizontalTextPosition(JLabel.CENTER);
        signupLabel.setForeground(Color.WHITE);
        signupLabel.setFont(new Font("Times New Roman",Font.BOLD,30));
        signupLabel.setBounds(200, 0, 500, 100);
        
        //----------SIGNUP NAME LAYOUT----------
        signupname.setFont(new Font("Consolas",Font.PLAIN,15));
        signupname.setBounds(200, 160, 250, 25);
        signuserLabel.setText("Name");
        signuserLabel.setFont(new Font("Consolas",Font.BOLD,18));
        signuserLabel.setBounds(120, 165, 100, 25);
        signuserLabel.setForeground(Color.WHITE);
        
        //----------SIGNUP EMAIL LAYOUT---------
        signupemail.setFont(new Font("Consolas",Font.PLAIN,15));
        signupemail.setBounds(200, 240, 250, 25);
        signemailLabel.setText("E-mail");
        signemailLabel.setFont(new Font("Consolas",Font.BOLD,18));
        signemailLabel.setBounds(120, 245, 100, 25);
        signemailLabel.setForeground(Color.WHITE);
        
        //---------SIGNUP PINCODE LAYOUT---------
        signuppin.setFont(new Font("Consolas",Font.PLAIN,15));
        signuppin.setBounds(200, 320, 250, 25);
        signpinLabel.setText("Pincode");
        signpinLabel.setFont(new Font("Consolas",Font.BOLD,18));
        signpinLabel.setBounds(120, 325, 100, 25);
        signpinLabel.setForeground(Color.WHITE);
        
        //---------SIGNUP SUBMIT BUTTON---------
        signsubmit.setBounds(400, 420, 100, 40);
        signsubmit.setFocusable(false);
        signsubmit.setFont(new Font("Times New Roman",Font.BOLD,20));
        signsubmit.setBorder(BorderFactory.createEtchedBorder());
        signsubmit.addActionListener((e) -> {
            String name = signupname.getText();
            String email = signupemail.getText();
            String pincode = signuppin.getText();
            try {
                temp = new User(name, email, pincode);
                User.signup(temp);
                User.writeusers();
                signupFrame.setVisible(false);
                registerFrame.setVisible(true);
            } catch (Exception exp) {
                temp = null;
                JOptionPane.showMessageDialog(null, "Enter the correct E-mail format!", "Failed Signup", JOptionPane.WARNING_MESSAGE);
            }
            
            
        });
        
        
        //-----------BACK BUTTON-----------
        signupback=new JButton();
        signupback.addActionListener((e) -> {
            signupFrame.setVisible(false);
            mainFrame.setVisible(true);
        });
        signupback.setText("Back");
        signupback.setBounds(Rectangle.OUT_LEFT, 470, 100, 40);
        signupback.setFocusable(false);
        signupback.setFont(new Font("Times New Roman",Font.BOLD,20));
        signupback.setBorder(BorderFactory.createEtchedBorder());
        
        
        //-----------FRAME BODY--------------
        signupFrame.setTitle("Airline Reservation System"); 
  signupFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
  signupFrame.setResizable(false); 
  signupFrame.setSize(550,550); 
  signupFrame.setLayout(null);
  signupFrame.add(signupLabel);
  signupFrame.add(signupname);
  signupFrame.add(signuserLabel);
  signupFrame.add(signsubmit);
  signupFrame.add(signupemail);
  signupFrame.add(signemailLabel);
  signupFrame.add(signuppin);
  signupFrame.add(signpinLabel);
  signupFrame.add(signupback);
  signupFrame.setIconImage(image.getImage()); 
  signupFrame.getContentPane().setBackground(new Color(0x123456)); 
  signupFrame.setVisible(false);
  
  
  
  
        //--------------------------REGISRTY FRAME----------------------------
        
        JButton registerButton,modifyButton,deleteButton,registryback;
        JLabel registryLabel,tripLabel,seatsLabel,seatTypeLabel,tripTypeLabel;
        JComboBox tripsBox,seatsBox;
        JRadioButton onewayButton,twowayButton;
        JRadioButton economyButton,businessButton;
        
        //--------REGISTRY TITLE------------
        registryLabel = new JLabel("Registry");
        registryLabel.setHorizontalTextPosition(JLabel.CENTER);
        registryLabel.setForeground(Color.WHITE);
        registryLabel.setFont(new Font("Times New Roman",Font.BOLD,40));
        registryLabel.setBounds(290, 0, 500, 100);
        
        //-------TRIPS LAYOUT-----------
        String[] trips = new String[s.getFlights().size()];
        for (int i = 0; i < s.getFlights().size(); i++) {
            trips[i] = s.getFlights().get(i).toString();
        }
        tripsBox = new JComboBox(trips);
        tripsBox.setBounds(250, 150, 320, 50);
        tripsBox.addActionListener((e) -> {
            try {
                trip = (s.getFlights().get(tripsBox.getSelectedIndex())).clone();
            } catch (CloneNotSupportedException ex) {
                Logger.getLogger(AirlineSystem.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        tripLabel = new JLabel("Flight");
        tripLabel.setFont(new Font("Consolas",Font.BOLD,21));
        tripLabel.setBounds(165, 165, 100, 25);
        tripLabel.setForeground(Color.WHITE);
        
        //--------SEATS LAYOUT----------
        Integer[] seatsInteger = {1,2,3,4,5,6,7,8,9,10}; 
        seatsBox = new JComboBox(seatsInteger);
        seatsBox.setBounds(250, 220, 320, 50);
        seatsBox.addActionListener((e) -> {
             seats = (int) seatsBox.getSelectedItem();
        });
        seatsLabel = new JLabel("No. of Seats");
        seatsLabel.setFont(new Font("Consolas",Font.BOLD,21));
        seatsLabel.setBounds(100, 235, 150, 25);
        seatsLabel.setForeground(Color.WHITE);
        
        //---------SEAT TYPE LAYOUT--------
        economyButton = new JRadioButton("Economy");
        businessButton = new JRadioButton("Business");
        ButtonGroup seatclass = new ButtonGroup();
        seatclass.add(economyButton);
        seatclass.add(businessButton);
        economyButton.setBounds(250, 295, 100, 40);
        businessButton.setBounds(380, 295, 100, 40);
        economyButton.addActionListener((e) -> {
            seat_Type=Seat_Type.economy;
        });
        businessButton.addActionListener((e) -> {
            seat_Type=Seat_Type.business;
        });
        seatTypeLabel = new JLabel("Seat class");
        seatTypeLabel.setFont(new Font("Consolas",Font.BOLD,21));
        seatTypeLabel.setBounds(100, 305, 150, 25);
        seatTypeLabel.setForeground(Color.WHITE);
        
        //--------TRIP TYPE LAYOUT-----------
        onewayButton = new JRadioButton("1 way");
        twowayButton = new JRadioButton("2 way");
        ButtonGroup triptype = new ButtonGroup();
        triptype.add(onewayButton);
        triptype.add(twowayButton);
        onewayButton.setBounds(250, 355, 100, 40);
        twowayButton.setBounds(380, 355, 100, 40);
        onewayButton.addActionListener((e) -> {
            trip_Type=Trip_Type.OneWay;
        });
        twowayButton.addActionListener((e) -> {
            trip_Type=Trip_Type.TwoWay;
        });
        tripTypeLabel = new JLabel("Trip type");
        tripTypeLabel.setFont(new Font("Consolas",Font.BOLD,21));
        tripTypeLabel.setBounds(100, 365, 150, 25);
        tripTypeLabel.setForeground(Color.WHITE);
        
        //---------REGISTRY BUTTONS LAYOUT---------
        registerButton=new JButton();
        registerButton.addActionListener((e) -> {
            if(temp.getT()!=null)
                {
                    JOptionPane.showMessageDialog(null, "You already Registered a Ticket!", "Failed Registration", JOptionPane.WARNING_MESSAGE);
                }
            else
                {
                    temp.setTicket(new Ticket(trip,temp,seat_Type,trip_Type,seats));
                    JOptionPane.showMessageDialog(null, "Ticket successfully registered!", "Successful Registration", JOptionPane.INFORMATION_MESSAGE);
                }
        });
        registerButton.setText("Register");
        registerButton.setBounds(150, 450, 100, 40);
        registerButton.setFocusable(false);
        registerButton.setFont(new Font("Times New Roman",Font.BOLD,20));
        registerButton.setBorder(BorderFactory.createEtchedBorder());
        //-------------
        modifyButton=new JButton();
        modifyButton.addActionListener((e) -> {
            if(temp.getT()!=null)
                {
                    try {
                    temp.getT().setT(trip.clone());
                    temp.getT().setSeatType(seat_Type);
                    temp.getT().setSeats(seats);
                    temp.getT().setTriptype(trip_Type);
                    JOptionPane.showMessageDialog(null, "Ticket Modified Successfully!", "Successfull Modification", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception exp) {
                    JOptionPane.showMessageDialog(null, "Modification failed!!!", "Failed Modification", JOptionPane.ERROR_MESSAGE);
                }
                   
                }
                else{
                
                 JOptionPane.showMessageDialog(null, "There's no registered Ticket!", "Failed Modification", JOptionPane.WARNING_MESSAGE);
                
            }
        });
        modifyButton.setText("Modify");
        modifyButton.setBounds(320, 450, 100, 40);
        modifyButton.setFocusable(false);
        modifyButton.setFont(new Font("Times New Roman",Font.BOLD,20));
        modifyButton.setBorder(BorderFactory.createEtchedBorder());
        //-------------
        deleteButton=new JButton();
        deleteButton.addActionListener((e) -> {
             if(temp.getT()==null)
                {
                    JOptionPane.showMessageDialog(null, "There's no registered Ticket!", "Failed Removal", JOptionPane.WARNING_MESSAGE);
                }
                else{
                 temp.delete();
                 JOptionPane.showMessageDialog(null, "Ticket Deleted!", "Successfull Removal", JOptionPane.INFORMATION_MESSAGE);
             }
        });
        deleteButton.setText("Delete");
        deleteButton.setBounds(490, 450, 100, 40);
        deleteButton.setFocusable(false);
        deleteButton.setFont(new Font("Times New Roman",Font.BOLD,20));
        deleteButton.setBorder(BorderFactory.createEtchedBorder());
        
        
        //--------REGISTRY BACK BUTTON---------
        registryback=new JButton();
        registryback.addActionListener((e) -> {
            registerFrame.setVisible(false);
            loginFrame.setVisible(true);
        });
        registryback.setText("Back");
        registryback.setBounds(Rectangle.OUT_LEFT, 670, 100, 40);
        registryback.setFocusable(false);
        registryback.setFont(new Font("Times New Roman",Font.BOLD,20));
        registryback.setBorder(BorderFactory.createEtchedBorder());
        
        
        
        //--------FRAME BODY---------
        registerFrame.setTitle("Airline Reservation System"); 
  registerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
  registerFrame.setResizable(false); 
  registerFrame.setSize(750,750); 
  registerFrame.setLayout(null);
  registerFrame.add(registryLabel);
  registerFrame.add(tripsBox);
  registerFrame.add(tripLabel);
  registerFrame.add(seatsBox);
  registerFrame.add(seatsLabel);
  registerFrame.add(economyButton);
  registerFrame.add(businessButton);
  registerFrame.add(seatTypeLabel);
  registerFrame.add(onewayButton);
  registerFrame.add(twowayButton);
  registerFrame.add(tripTypeLabel);
  registerFrame.add(registerButton);
  registerFrame.add(deleteButton);
  registerFrame.add(modifyButton);
  registerFrame.add(registryback);
 
  
  registerFrame.setIconImage(image.getImage()); 
  registerFrame.getContentPane().setBackground(new Color(0x123456));
    registerFrame.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
    }
    
}
