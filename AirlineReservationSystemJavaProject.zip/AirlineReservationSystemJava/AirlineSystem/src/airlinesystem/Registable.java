
package airlinesystem;

public interface Registable {
    void addESeats(int t);
    void addBSeats(int t);
    void deleteESeats(int t);
    void deleteBSeats(int t);
}
