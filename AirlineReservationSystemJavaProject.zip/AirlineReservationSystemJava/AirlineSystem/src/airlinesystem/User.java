
package airlinesystem;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class User implements Modifiable {
    
    private String name;
    private String email;
    private String pincode;
    private Ticket t;
    private static ArrayList<User> registeredUsers = new ArrayList<>();
    
    public User(String name,String email,String pincode) throws RuntimeException{
        this.name=name;
        if(email.matches(".*@.*.com"))
            this.email=email;
        else
            throw new RuntimeException();
        this.pincode=pincode;   
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) throws RuntimeException {
        if(email.matches(".*@.*.com"))
            this.email=email;
        else
            throw new RuntimeException();
    }

    public String getName() {
        return name;
    }

    public String getPincode() {
        return pincode;
    }

    public String getEmail() {
        return email;
    }
    public void setTicket(Ticket t ) {
       this.t = t;
    }
    
    public Ticket getT() {
        return t;
    }

    @Override
    public void modify(Trip newTrip, Seat_Type newSeat_Type, Trip_Type newTrip_Type, int newSeats) throws RuntimeException {
        try {
            t.setT(newTrip);
            t.setSeatType(newSeat_Type);
            t.setSeats(newSeats);
            t.setTriptype(newTrip_Type);
        } catch (Exception e) {
            throw new RuntimeException();
        }
        
        
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.pincode);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.pincode, other.pincode)) {
            return false;
        }
        return true;
    }

    @Override
    public void delete(){
        try {
            if(t.getSeatType()==Seat_Type.economy)
           t.addESeats(t.getSeats());
       else if(t.getSeatType()==Seat_Type.business)
           t.addBSeats(t.getSeats());
            
        } catch (Exception e) {
            System.out.println("Error");
        }
       
       t = null;
       
    }
    public static void readusers() throws RuntimeException{
        try {
            File f = new File("D:\\Users.txt");
            Scanner input = new Scanner(f);
            while(input.hasNextLine())
            {
                String name = input.next();
                String email = input.next();
                String pincode = input.next();
                registeredUsers.add(new User(name,email,pincode));
            }
            input.close();
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
    
    public static void writeusers() throws RuntimeException{
        try {
            File f = new File("D:\\Users.txt");
            PrintWriter out = new PrintWriter(f);
            for (int i = 0; i < registeredUsers.size(); i++) {
                out.print("\n"+registeredUsers.get(i));
            }
            out.close();
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
    
    public static User login(String email,String pincode) {
        
        for (int i = 0; i < registeredUsers.size(); i++) {
            if(registeredUsers.get(i).email.equals(email) && registeredUsers.get(i).pincode.equals(pincode)) {
                return registeredUsers.get(i);
            }
        }
        
        return null;
    }
    
    public static User login(User other) {
        if(registeredUsers.contains(other)) {
            return registeredUsers.get(registeredUsers.indexOf(other));
        }
        return null;
    }
    
    public static void signup(User other){
        registeredUsers.add(other);
    }

    @Override
    public String toString() {
        return name+" "+email+" "+pincode;
    }
    
    
}
