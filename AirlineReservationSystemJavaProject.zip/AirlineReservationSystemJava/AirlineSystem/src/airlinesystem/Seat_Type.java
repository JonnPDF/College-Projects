
package airlinesystem;


public enum Seat_Type {
    economy,business
    
}
