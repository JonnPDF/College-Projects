<?php
define('SERVER','localhost');
define('DBUSER','root');
define('DBPASS','');
define('DBNAME','myproject');
?>
