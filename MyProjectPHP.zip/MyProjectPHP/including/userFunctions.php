<?php 

function login($username,$password)
{
	//1 - 
	$connection  = mysqli_connect(SERVER,DBUSER,DBPASS,DBNAME);
	if(!$connection)
		exit("ERROR : ".mysqli_connect_error());
	//2- query
	$query = mysqli_query($connection,"SELECT * FROM `users` WHERE `username`='$username' AND `password`='$password'");
	if(mysqli_num_rows($query)>0)
	{
		$row = mysqli_fetch_assoc($query);
		$_SESSION['username'] = $username;
		$_SESSION['userid'] = $row['id'];
		mysqli_close($connection);
		return true;
	}
	else
	{
		mysqli_close($connection);
		return false;
	}

}

function checkLogin()
{
	if(isset($_SESSION['username']))
		return true;

	return false;
}

function logout()
{
	session_destroy();
}

?>