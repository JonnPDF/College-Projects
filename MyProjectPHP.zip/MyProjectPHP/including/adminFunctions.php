<?php

function addClient($userfname,$userlname,$username,$city,$zip,$pass,$phone,$email)
{
    //1-connection
    $connection = mysqli_connect(SERVER,DBUSER,DBPASS,DBNAME);
    if(!$connection)
        exit("Error : ".mysqli_connect_error());

    //2-query
    $query = mysqli_query($connection,"INSERT INTO `users`(`firstname`,`lastname`,`username`, `email`, `phone`, `city`,`zip`,`password`) VALUES ('$userfname','$userlname','$username','$email','$phone','$city',$zip,'$pass')");

    if(mysqli_affected_rows($connection) >0)
    {
        //3- close
        mysqli_close($connection);
        return true;
    }
    //3- close
    mysqli_close($connection);
    return false;
}


function updateUser($id,$userfname,$userlname,$username,$city,$zip,$pass,$phone,$email)
{
    //1-connection
    $connection = mysqli_connect(SERVER,DBUSER,DBPASS,DBNAME);
    if(!$connection)
        exit("Error : ".mysqli_connect_error());

    //2-query
    $query = mysqli_query($connection,"UPDATE `users` SET `firstname`='$userfname',`lastname`='$userlname',`username`='$username',`zip`=$zip,`password`='$pass', `email`='$email', `phone`='$phone', `city`='$city' WHERE `id`=$id");

    if(mysqli_affected_rows($connection) >0)
    {
        //3- close
        mysqli_close($connection);
        return true;
    }
    //3- close
    mysqli_close($connection);
    return false;
}

function deleteUser($id)
{
    //1-connection
    $connection = mysqli_connect(SERVER,DBUSER,DBPASS,DBNAME);
    if(!$connection)
        exit("Error : ".mysqli_connect_error());


    //2-query
    $query = mysqli_query($connection,"DELETE FROM `users` WHERE `id`=$id");

    if(mysqli_affected_rows($connection) >0)
    {
        //3- close
        mysqli_close($connection);
        return true;
    }
    //3- close
    mysqli_close($connection);
    return false;
}


function getUsers()
{
    //1-connection
    $connection = mysqli_connect(SERVER,DBUSER,DBPASS,DBNAME);
    if(!$connection)
        exit("Error : ".mysqli_connect_error());

    //2-query
    $query = mysqli_query($connection,"SELECT * FROM `users`");

    $clients = [];
    if(mysqli_num_rows($query) >0)
    {
        while($row = mysqli_fetch_assoc($query))
            $clients[] = $row;
    }
    //3- close
    mysqli_close($connection);
    return $clients;
}



function searchUsers($keyword)
{
    //1-connection
    $connection = mysqli_connect(SERVER,DBUSER,DBPASS,DBNAME);
    if(!$connection)
        exit("Error : ".mysqli_connect_error());

    //2-query
    $query = mysqli_query($connection,"SELECT * FROM `users` WHERE `firstname` LIKE '%$keyword%' OR `lastname` LIKE '%$keyword%' OR `username` LIKE '%$keyword%' OR `city` LIKE '%$keyword%' OR `zip` LIKE '%$keyword%' OR `phone` LIKE '%$keyword%' OR `email` LIKE '%$keyword%'");

    $clients = [];
    if(mysqli_num_rows($query) >0)
    {
        while($row = mysqli_fetch_assoc($query))
            $clients[] = $row;
    }
    //3- close
    mysqli_close($connection);
    return $clients;
}



function getUser ($id)
{
    //1-connection
    $connection = mysqli_connect(SERVER,DBUSER,DBPASS,DBNAME);
    if(!$connection)
        exit("Error : ".mysqli_connect_error());

    //2-query
    $query = mysqli_query($connection,"SELECT * FROM `users` WHERE `id`=$id");

    $client = [];
    if(mysqli_num_rows($query) >0)
    {
        $client = mysqli_fetch_assoc($query);
    }
    //3- close
    mysqli_close($connection);
    return $client;
}

?>