<?php if(!checkLogin()) { ?>

<header>
    <nav id="nav-menu" class="navbar navbar-default">
        <div id="elements" class="container-fluid">

            <a class="navbar-brand" href="index.php">
                <img id="logo" style="border-radius: 15px;" src="https://www.pngkit.com/png/detail/67-672385_drawn-logo-vans-cool-logos-easy-to-draw.png" alt="Logo">
            </a>

            <ul id="menu-list" class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                
            </ul>
            <span id="welcome" class="pull-right">Welcome,User</span>
        </div>
        
    </nav>
</header>

<?php } else if ($_SESSION['username']=='admin') {
?>

<header>
    <nav id="nav-menu" class="navbar navbar-default">
        <div id="elements" class="container-fluid">

            <a class="navbar-brand" href="index.php">
                <img id="logo" style="border-radius: 15px;" src="https://www.pngkit.com/png/detail/67-672385_drawn-logo-vans-cool-logos-easy-to-draw.png" alt="Logo">
            </a>

            <ul id="menu-list" class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="admin.php">Dashboard</a></li>
            <li><a href="logout.php">Logout</a></li>
            </ul>
            <span id="welcome" class="pull-right">Welcome,<?php echo $_SESSION['username'] ?></span>
        </div>
        
    </nav>
</header>

<?php } else { ?>

<header>
    <nav id="nav-menu" class="navbar navbar-default">
        <div id="elements" class="container-fluid">

            <a class="navbar-brand" href="index.php">
                <img id="logo" style="border-radius: 15px;" src="https://www.pngkit.com/png/detail/67-672385_drawn-logo-vans-cool-logos-easy-to-draw.png" alt="Logo">
            </a>

            <ul id="menu-list" class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="userdetails.php">Details</a></li>
            <li><a href="logout.php">Logout</a></li>
            </ul>
            <span id="welcome" class="pull-right">Welcome,<?php echo $_SESSION['username'] ?></span>
        </div>
        
    </nav>
</header>

<?php } ?>