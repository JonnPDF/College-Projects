<?php
if(!checkLogin()){
    header('Location: login.php');
    die();
}
?>