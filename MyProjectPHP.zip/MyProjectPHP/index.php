<?php
require 'including/config.php';
require 'including/adminFunctions.php';
require 'including/userFunctions.php';
session_start();
require 'including/validateLogin.php';
$users = getUsers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'including/html-css-config.html' ?>
    <title>Home Page</title>
</head>
<body>

    <?php include 'including/navigation.php'; ?>
    <main>
        
    </main>
    <?php include 'including/foot.html'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>
</html>