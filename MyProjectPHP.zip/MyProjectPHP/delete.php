<?php
session_start();
require 'including/config.php';
require 'including/adminFunctions.php';
require 'including/userFunctions.php';
require 'including/validateLogin.php';

if(!checkLogin())
    header("LOCATION: login.php");

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(deleteUser($id))
    echo "deleted <br>
            <a href='admin.php'>Go back</a>";
else
    echo "not deleted <br>
    <a href='admin.php'>Go back</a>";
?>