<?php
require 'including/config.php';
require 'including/adminFunctions.php';
require 'including/userFunctions.php';
session_start();
require 'including/validateLogin.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(count($_POST) > 0 && $_POST['userpass']==$_POST['confirmpass'])
{
    $user = getUser($id);
    $firstname   = $user['firstname'];
    $lastname   = $user['lastname'];
    $username   = $user['username'];
    $phone  = $user['phone'];
    $city   = $user['city'];
    $zip   = $user['zip'];
    $email  = $user['email'];
    $pass = $_POST['userpass'];
	if(updateUser($id,$firstname,$lastname,$username,$city,$zip,$pass,$phone,$email))
		echo 'client updated successfully <a href="userdetails.php">Go back</a>';
	else
		echo 'user not updated <a href="userdetails.php">Go back</a>';


}
else
{

	$user = getUser($id);

	if(count($user) == 0)
		exit('invalid client selected');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'including/html-css-config.html' ?>
    <title>Home Page</title>
</head>
<body>

    <?php include 'including/navigation.php'; ?>
    <main>
    <div class="container">
    <h1 class="well">Update Form</h1>
	<div class="col-lg-12 well">
	<div class="row">
				<form method="POST" action="useredit.php?id=<?php echo $id; ?>">
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>First Name</label>
								<input type="text" name="userfname" placeholder="Dwayne" class="form-control" value="<?php echo $user['firstname']; ?>" disabled>
							</div>
							<div class="col-sm-6 form-group">
								<label>Last Name</label>
								<input type="text" name="userlname" placeholder="Johnson" class="form-control" value="<?php echo $user['lastname']; ?>" disabled>
							</div>
						</div>
                        <div class="form-group">
						    <label>Username</label>
						    <input type="text" name="username" placeholder="TheRock" class="form-control" value="<?php echo $user['username']; ?>" disabled>
					    </div>
                        <div class="row">
							<div class="col-sm-6 form-group">
								<label>New Password</label>
								<input type="password" name="userpass" placeholder="********" class="form-control" required>
							</div>		
							<div class="col-sm-6 form-group">
								<label>Confirm Password</label>
								<input type="password" name="confirmpass" placeholder="********" class="form-control" required>
							</div>	
						</div>		
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>City</label>
								<input type="text" name="usercity" placeholder="Cairo" class="form-control" value="<?php echo $user['city']; ?>" disabled>
							</div>	
							<div class="col-sm-6 form-group">
								<label>Zip</label>
								<input type="text" name="userzip" placeholder="12345" class="form-control" value="<?php echo $user['zip']; ?>" disabled>
							</div>		
						</div>						
					<div class="form-group">
						<label>Phone Number</label>
						<input type="text" name="userphone" placeholder="+20 123 456 7890" class="form-control" value="<?php echo $user['phone']; ?>" disabled>
					</div>		
					<div class="form-group">
						<label>Email Address</label>
						<input type="email" name="usermail" placeholder="example@example.com" class="form-control" value="<?php echo $user['email']; ?>" disabled>
					</div>
					<button type="submit" class="btn btn-lg btn-info">Submit</button>					
					</div>
				</form> 
				</div>
                <?php 
	if(count($_POST)>0) {
		
		if($_POST['userpass']!=$_POST['confirmpass']){
			echo "<br><br><div class='alert alert-danger alert-dismissible' role='alert'><b>Update Failed!</b> 
        	Enter Password correctly</a></div>";
		}
    } 
    ?>
	</div>
    </main>
    <?php include 'including/foot.html'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>
</html>

<?php } ?>