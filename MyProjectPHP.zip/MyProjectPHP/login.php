<?php
require 'including/userFunctions.php';
require 'including/config.php';
session_start();
if(count($_POST)>0){
    if($_POST['username']=='admin' && $_POST['userpass']=='admin'){
        $_SESSION['username']='admin';
        header("Location: index.php");
        die();
    }
    else if (login($_POST['username'],$_POST['userpass'])){
      header("Location: index.php");
      die();
    }
}
if(checkLogin()){
  header("Location: index.php");
  die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    
    <?php require 'including/html-css-config.html'; ?>
    <title>Login</title>
</head>
<body>

    <?php include 'including/navigation.php'; ?>

    <main class="container-fluid">
    <div class="back">


  <div class="div-center">


    <div class="content">


      <h3>Login</h3>
      <hr/>
      <form action="login.php" method="POST">
        <div class="form-group">
            
          <label for="exampleInputEmail1">Username</label>
          <div class="input-group">
          <div class="input-group-addon glyphicon glyphicon-user" style="bottom: 0px;top: 0px;"></div>
          <input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Username">
        </div></div>
        <div class="form-group">
            
          <label for="exampleInputPassword1">Password</label>
          <div class="input-group">
          <div class="input-group-addon glyphicon glyphicon-asterisk" style="bottom: 0px;top: 0px;"></div>
          <input type="password" name="userpass" class="form-control" id="exampleInputPassword1" placeholder="**************">
        </div></div>
        <button type="submit" class="btn btn-default">Login</button>
        <?php
        if(count($_POST)>0) {
            echo "<br><br><div class='alert alert-danger' role='alert'><b>Login Failed!</b> 
            Enter username and password correctly or <a class='alert-link'  href='signup.php'>Signup!</a></div>";
        } 
        ?>
        <hr/>
        <a href="signup.php">Don't have an account? Signup now!</a>
        <br><br>
      </form>

    </div>


    </span>
  </div>
    </main>

    <?php include 'including/foot.html'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>
</html>