<?php 
session_start();
require 'including/config.php';
require 'including/adminFunctions.php';
require 'including/userFunctions.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require 'including/html-css-config.html'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <title>Signup</title>
</head>
<body>

    <?php include 'including/navigation.php' ?>

    <main>
    <form action="signup.php" method="POST">
    <div class="container">
    <h1 class="well">Registration Form</h1>
	<div class="col-lg-12 well">
	<div class="row">
				<form method="POST" action="signup.php">
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>First Name</label>
								<input type="text" name="userfname" placeholder="Dwayne" class="form-control" required>
							</div>
							<div class="col-sm-6 form-group">
								<label>Last Name</label>
								<input type="text" name="userlname" placeholder="Johnson" class="form-control" required>
							</div>
						</div>
                        <div class="form-group">
						    <label>Username</label>
						    <input type="text" name="username" placeholder="TheRock" class="form-control" required>
					    </div>		
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>City</label>
								<input type="text" name="usercity" placeholder="Cairo" class="form-control" required>
							</div>	
							<div class="col-sm-6 form-group">
								<label>Zip</label>
								<input type="text" name="userzip" placeholder="12345" class="form-control" required>
							</div>		
						</div>
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Password</label>
								<input type="password" name="userpass" placeholder="********" class="form-control" required>
							</div>		
							<div class="col-sm-6 form-group">
								<label>Confirm Password</label>
								<input type="password" name="confirmpass" placeholder="********" class="form-control" required>
							</div>	
						</div>						
					<div class="form-group">
						<label>Phone Number</label>
						<input type="text" name="userphone" placeholder="+20 123 456 7890" class="form-control" required>
					</div>		
					<div class="form-group">
						<label>Email Address</label>
						<input type="email" name="usermail" placeholder="example@example.com" class="form-control" required>
					</div>
					<button type="submit" class="btn btn-lg btn-info">Submit</button>					
					</div>
				</form> 
				</div>
	</div>
	<?php 
	if(count($_POST)>0) {
		
		if($_POST['userpass']!=$_POST['confirmpass']){
			echo "<br><br><div class='alert alert-danger alert-dismissible' role='alert'><b>Signup Failed!</b> 
        	Enter Password correctly</a></div>";
		}
		else if (!addClient($_POST['userfname'],$_POST['userlname'],$_POST['username'],$_POST['usercity'],$_POST['userzip'],$_POST['userpass'],$_POST['userphone'],$_POST['usermail'])){
			echo "<br><br><div class='alert alert-danger alert-dismissible' role='alert'><b>Signup Failed!</b> 
			Enter data correctly</div>";
		}
		else {
			echo "<br><br><div class='alert alert-success alert-dismissible' role='alert'><b>Signup Success!</b> 
			You can <a href='login.php' class='alert-link' >Go to Login</a></div>";
		}
    } 
    ?>
	</div>
    </form>

	

    </main>
    <?php include 'including/foot.html'; ?>
</body>
</html>