<?php
require 'including/config.php';
require 'including/adminFunctions.php';
require 'including/userFunctions.php';
session_start();
require 'including/validateLogin.php';
$users = searchUsers($_GET['keyword']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'including/html-css-config.html' ?>
    <title>Dashboard</title>
</head>
<body>

    <?php include 'including/navigation.php'; ?>

    <center>
    <main>
        <h1>User Results</h1>
        
        <table class="table table-hover" style="width:98% ;">
            <tr>
                <th>ID</th>
                <th>FirstName</th>
                <th>LastName</th>
                <th>Username</th>
                <th>Phone</th>
                <th>City</th>
                <th>ZIP</th>
                <th>E-mail</th>
                <th>Control</th>
            </tr>

            <?php
                foreach ($users as $user)
                {
                    $id     = $user['id'];
                    $firstname   = $user['firstname'];
                    $lastname   = $user['lastname'];
                    $username   = $user['username'];
                    $phone  = $user['phone'];
                    $city   = $user['city'];
                    $zip   = $user['zip'];
                    $email  = $user['email'];

                    echo "
                        <tr>
                            <td>$id</td>
                            <td>$firstname</td>
                            <td>$lastname</td>
                            <td>$username</td>
                            <td>$phone</td>
                            <td>$city</td>
                            <td>$zip</td>
                            <td>$email</td>
                            <td>
                                <a class='btn glyphicon glyphicon-remove' href='delete.php?id=$id'></a>
                                <a class='btn glyphicon glyphicon-pencil' href='update.php?id=$id'></a>
                            </td>
                        </tr>        
                    ";
                }

            ?>

        </table>
        <a class="btn btn-info" href="signup.php">Add new user</a>
        <a class="btn btn-default" href="admin.php">Go back</a>
        <br><br>
    </main>
</center>

    <?php include 'including/foot.html'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>
</html>