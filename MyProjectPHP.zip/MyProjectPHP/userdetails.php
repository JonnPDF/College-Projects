<?php
require 'including/config.php';
require 'including/adminFunctions.php';
require 'including/userFunctions.php';
session_start();
require 'including/validateLogin.php';
$user = getUser($_SESSION['userid']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'including/html-css-config.html' ?>
    <title>Home Page</title>
</head>
<body>

    <?php include 'including/navigation.php'; ?>
    <main>
        
            <div class="container" style="font-size: 1.5em ;">
                <center>
                    <img width="180" height="180" src="https://d1nhio0ox7pgb.cloudfront.net/_img/o_collection_png/green_dark_grey/512x512/plain/user.png" alt="User" class="img-circle">
                    <h2><?php echo $user['username']; ?></h2>
                </center>
                <p><b>FirstName: </b> <?php echo $user['firstname']; ?> </p>
                <p><b>LastName: </b> <?php echo $user['lastname']; ?> </p>
                <p><b>Password: </b> <?php echo $user['password']; ?> &nbsp; <a class="btn glyphicon glyphicon-pencil" href="useredit.php?id=<?php echo $user['id'] ?>" style="padding-bottom: 0px;padding-top: 0px;top: -1px;"></a> </p>
                <p><b>City: </b> <?php echo $user['city']; ?> </p>
                <p><b>ZIP code: </b> <?php echo $user['zip']; ?> </p>
                <p><b>E-mail: </b> <?php echo $user['email']; ?> </p>
                <p><b>Phone Number: </b> <?php echo $user['phone']; ?> </p>
            </div>
        
        
    </main>
    <?php include 'including/foot.html'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>
</html>