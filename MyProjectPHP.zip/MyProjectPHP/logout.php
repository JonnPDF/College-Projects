<?php
session_start();
require 'including/userFunctions.php';
logout();
header("LOCATION: login.php");
?>